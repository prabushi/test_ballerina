package org.factory.project;

import org.factory.project.model.Job;
import org.factory.project.model.input.DfAllocation;
import org.factory.project.model.input.OperationData;
import org.factory.project.model.input.WorkerInput;
import org.factory.project.utils.FactoryUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.util.*;

public class TestOutput {

    @Test
    public void testDependency() throws ParseException {
        Map<Integer, List<DfAllocation>> allocationsPerWorker = new HashMap<>();
        allocationsPerWorker.put(1, new ArrayList<>());
        allocationsPerWorker.put(2, new ArrayList<>());
        allocationsPerWorker.put(3, new ArrayList<>());
        allocationsPerWorker.put(4, new ArrayList<>());

        Job[] jobList = FactoryOperation.getJobList();

        Map<Integer, Map<Integer, OperationData>> operationMap = new HashMap<>();
        for (int i = 0; i < FactoryOperation.JOB_COUNT; i++) {
            operationMap.put(i + 1, new HashMap<>());
        }

        List<DfAllocation> allocations = FactoryUtils.readDfAllocationInput("/Users/ts-p.samarakoonarach/Rakuten/practice/MiProject/src/main/resources/input/df_Allocation_pyCharm_iterated_1.csv");//"/Users/ts-p.samarakoonarach/Rakuten/practice/MiProject/result_4.csv");
        for (DfAllocation allocation : allocations) {
            System.out.println(allocation.toString());
        }

        List<WorkerInput> workerInputs = FactoryUtils.readEngineerInput();
        for (WorkerInput workerInput : workerInputs) {
            System.out.println(workerInput.toString());
        }

        List<OperationData> operationDataList = FactoryUtils.readJobData();
        for (OperationData operationData : operationDataList) {
            int jobId = operationData.getJobId();
            int operationId = operationData.getOperationId();
            operationMap.get(jobId).put(operationId, operationData);

            jobList[jobId - 1].getOperationDataList().add(operationData);

            System.out.println(operationData);
        }

        //TODO: create worker priority list

        // Set dependencies
        for (OperationData operationData : operationDataList) {
            List<Integer> precedences = operationData.getPrecedingOperations();
            int jobId = operationData.getJobId();
            for (Integer p : precedences) {
                operationData.addDependency(operationMap.get(jobId).get(p.intValue()));
            }
        }

//        FactoryOperation.calculateTimeConsumption(allocations, workerInputs, jobList);

        // Check dependencies
        for (int i = 0; i < allocations.size(); i++) {
            DfAllocation allocation = allocations.get(i);
            OperationData operationData = jobList[allocation.getJobId() - 1].getOperationDataList().get(allocation.getOperationId() - 1);
            List<OperationData> dependencies = operationData.getDependentOperations();

            if (dependencies.size() > 0) {
                System.out.println("===starting jobId: " + allocation.getJobId() + " operationId: " + allocation.getOperationId());
            }

            dependencies.forEach(d -> {
                int opID = d.getOperationId();
                int jbId = d.getJobId();

                Date finish = getAllocation(allocations, jbId, opID).getEndTime();
                    System.out.println("jobId: " + allocation.getJobId() + " operationId: " + allocation.getOperationId() + " dependency : " + d.getOperationId() + " dependency endTime: " + finish + " allocation start time: " + allocation.getStartTime());
                    Assertions.assertTrue(finish.before(allocation.getStartTime()) || finish.equals(allocation.getStartTime()));
            });
        }

        // Check overlap
        for (int i = 0; i < allocations.size(); i++) {
            DfAllocation allocation = allocations.get(i);
            int workerId = allocation.getWorkerId();
            allocationsPerWorker.get(workerId).add(allocation);
        }

        for (int i = 0; i < 4; i++) {
            List<DfAllocation> allocationsListForWorker = allocationsPerWorker.get(i + 1);
            Collections.sort(allocationsListForWorker, Comparator.comparing(DfAllocation::getStartTime));

            for (int j = 0; j < allocationsListForWorker.size() - 1; j++) {
                Date first = allocationsListForWorker.get(j).getEndTime();

                for (int k = j + 1; k < allocationsListForWorker.size(); k++) {
                    Date next = allocationsListForWorker.get(k).getStartTime();
                    Assertions.assertTrue(first.before(next) || first.equals(next), "Failed for job " + allocationsListForWorker.get(j).getJobId() +
                            ": " + allocationsListForWorker.get(j).getOperationId() + "next job " + allocationsListForWorker.get(j + 1).getJobId() +
                            ": " + allocationsListForWorker.get(j + 1).getOperationId());
                }
            }
        }

    }

    private DfAllocation getAllocation(List<DfAllocation> allocations, int jobId, int operationId) {
        for (int i = 0; i < allocations.size(); i++) {
            DfAllocation allocation = allocations.get(i);
            if (allocation.getJobId() == jobId && allocation.getOperationId() == operationId) {
                return allocation;
            }
        }
        return null;
    }
}
