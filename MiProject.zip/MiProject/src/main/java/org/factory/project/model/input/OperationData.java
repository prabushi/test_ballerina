package org.factory.project.model.input;

import org.factory.project.model.Task;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OperationData {
    private static final DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    private static final DateFormat finishFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    Integer jobId;
    Integer operationId;
    Integer standardTime;
    Task taskType;
    Double requiredSkillLimit;
    List<Integer> precedingOperations;
    boolean operationComplete;
    String lastCompletion; // 1 or 0
    Date dueDate;
    Date finishTime;
    List<Integer> assignedWorkers;


    boolean hasSetTime = false;
    List<OperationData> dependentOperations = new ArrayList<>();

    public OperationData(Integer jobId, Integer operationId, Integer standardTime, Task taskType, Double requiredSkillLimit, List<Integer> precedingOperations, boolean operationComplete, String lastCompletion, String dueDateStr, String finishTime, List<Integer> assignedWorkers) throws ParseException {
        this.jobId = jobId;
        this.operationId = operationId;
        this.standardTime = standardTime;
        this.taskType = taskType;
        this.requiredSkillLimit = requiredSkillLimit;
        this.precedingOperations = precedingOperations;
        this.operationComplete = operationComplete;
        this.lastCompletion = lastCompletion;
        dueDate = formatter.parse(dueDateStr);
        if (!finishTime.isBlank()) {
            this.finishTime = finishFormatter.parse(finishTime);
        } else {
            this.finishTime = null;
        }
        this.assignedWorkers = assignedWorkers;
    }

    // TODO: update
    public OperationData getMostPrioritizedOperation() {
        return null;
    }

    @Override
    public String toString() {
        return "{" +
                "jobId: " + jobId +
                ", operationId: " + operationId +
                ", standardTime: " + standardTime +
                ", taskType: " + taskType +
                ", requiredSkillLimit: " + requiredSkillLimit +
                ", precedingOperations: " + precedingOperations.toString() +
                ", operationComplete: " + operationComplete +
                ", lastCompletion: " + lastCompletion +
                ", dueDate: " + dueDate +
                ", finishTime: " + finishTime +
                ", assignedWorkers: " + assignedWorkers +
                "}";
    }

    public Integer getJobId() {
        return jobId;
    }

    public Integer getOperationId() {
        return operationId;
    }

    public Integer getStandardTime() {
        return standardTime;
    }

    public Task getTaskType() {
        return taskType;
    }

    public Double getRequiredSkillLimit() {
        return requiredSkillLimit;
    }

    public List<Integer> getPrecedingOperations() {
        return precedingOperations;
    }

    public void setOperationComplete(boolean operationComplete) {
        this.operationComplete = operationComplete;
    }

    public String getLastCompletion() {
        return lastCompletion;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public List<Integer> getAssignedWorkers() {
        return assignedWorkers;
    }

    public List<OperationData> getDependentOperations() {
        return dependentOperations;
    }

    public void addDependency(OperationData op) {
        if (op != null) {
            this.dependentOperations.add(op);
        }
    }

    public boolean isOperationComplete() {
        return operationComplete;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    public void setStandardTime(Integer standardTime) {
        this.standardTime = standardTime;
    }

    public void setTaskType(Task taskType) {
        this.taskType = taskType;
    }

    public void setRequiredSkillLimit(Double requiredSkillLimit) {
        this.requiredSkillLimit = requiredSkillLimit;
    }

    public void setPrecedingOperations(List<Integer> precedingOperations) {
        this.precedingOperations = precedingOperations;
    }

    public void setLastCompletion(String lastCompletion) {
        this.lastCompletion = lastCompletion;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public void setAssignedWorkers(List<Integer> assignedWorkers) {
        this.assignedWorkers = assignedWorkers;
    }

    public boolean isHasSetTime() {
        return hasSetTime;
    }

    public void setHasSetTime(boolean hasSetTime) {
        this.hasSetTime = hasSetTime;
    }
}
