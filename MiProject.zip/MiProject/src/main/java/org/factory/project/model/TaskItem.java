package org.factory.project.model;

public class TaskItem {
    private double skillLevel;
    private Task taskName;

    public TaskItem(double skillLevel, Task taskName) {
        this.skillLevel = skillLevel;
        this.taskName = taskName;
    }

    public double getSkillLevel() {
        return skillLevel;
    }

    public String getTaskName() {
        return taskName.getName();
    }

    public int getTaskId() {
        return taskName.getId();
    }
}
