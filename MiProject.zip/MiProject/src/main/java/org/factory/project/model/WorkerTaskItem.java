package org.factory.project.model;

public class WorkerTaskItem {
    private TaskItem taskItem;
    private int numberOfOperations;

    public WorkerTaskItem(TaskItem taskItem) {
        this.taskItem = taskItem;
        this.numberOfOperations = 0;
    }

    public int getNumberOfOperations() {
        return numberOfOperations;
    }

    public double getSkillLevel() {
        return taskItem.getSkillLevel();
    }

    public String getTaskName() {
        return taskItem.getTaskName();
    }

    public int getTaskId() {
        return taskItem.getTaskId();
    }
}
