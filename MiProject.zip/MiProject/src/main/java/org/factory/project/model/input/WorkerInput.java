package org.factory.project.model.input;

import org.factory.project.model.Task;
import org.factory.project.model.WorkerTaskItem;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WorkerInput {

    //2025-12-01 9:00:00
    private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Integer workerId;
    Integer rank;
    Integer workingTime; // hours per day + 2 overtime
    WorkerTaskItem[] taskItemList = new WorkerTaskItem[4];
    String assignedJobs;
    Integer[] taskCount;
    Integer workHours;
    Integer overtimeWorkHours;
    Date lastFinishTime;

    // including nonOT and OT
    Integer hoursPerToday = 0;
//    boolean isWorking = false;

    public WorkerInput(Integer workerId, Integer rank, Integer workingTime, WorkerTaskItem[] taskItemList, String assignedJobs, Integer[] taskCount, Integer workHours, Integer overtimeWorkHours, String lastFinishTime) throws ParseException {
        this.workerId = workerId;
        this.rank = rank;
        this.workingTime = workingTime;
        this.taskItemList = taskItemList;
        this.assignedJobs = assignedJobs;
        this.taskCount = taskCount;
        this.workHours = workHours;
        this.overtimeWorkHours = overtimeWorkHours;
        this.lastFinishTime = formatter.parse(lastFinishTime);
    }

    @Override
    public String toString() {
        return "{" +
                "worker: " + workerId +
                ", rank: " + rank +
                ", workingTime: " + workingTime +
                ", taskItemList: " + taskItemList[0].getSkillLevel() + ", " + taskItemList[1].getSkillLevel() + ", " + taskItemList[2].getSkillLevel() + ", " + taskItemList[3].getSkillLevel() +
                ", assignedJobs: " + assignedJobs +
                ", taskCount: " + taskCount[0] + ", " + taskCount[1] + ", " + taskCount[2] + ", " + taskCount[3] +
                ", workHours: " + workHours +
                ", overtimeWorkHours: " + overtimeWorkHours +
                ", lastFinishTime: " + lastFinishTime +
                "}";
    }

    public Double getSkillLimit(Task task) {
        for (int i = 0; i < 4; i++){
            WorkerTaskItem workerTaskItem = taskItemList[i];
            if (workerTaskItem.getTaskId() == task.getId()) {
                return workerTaskItem.getSkillLevel();
            }
        }

        return Double.valueOf(0);
    }

    public Integer getWorkerId() {
        return workerId;
    }

    public Integer getRank() {
        return rank;
    }

    public Integer getWorkingTime() {
        return workingTime;
    }

    public WorkerTaskItem[] getTaskItemList() {
        return taskItemList;
    }

    public String getAssignedJobs() {
        return assignedJobs;
    }

    public Integer[] getTaskCount() {
        return taskCount;
    }

    public Integer getWorkHours() {
        return workHours;
    }

    public Integer getOvertimeWorkHours() {
        return overtimeWorkHours;
    }

    public Date getLastFinishTime() {
        return lastFinishTime;
    }

//    public boolean isWorking() {
//        return isWorking;
//    }


    public void setWorkerId(Integer workerId) {
        this.workerId = workerId;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public void setWorkingTime(Integer workingTime) {
        this.workingTime = workingTime;
    }

    public void setTaskItemList(WorkerTaskItem[] taskItemList) {
        this.taskItemList = taskItemList;
    }

    public void setAssignedJobs(String assignedJobs) {
        this.assignedJobs = assignedJobs;
    }

    public void setTaskCount(Integer[] taskCount) {
        this.taskCount = taskCount;
    }

    public void incrementWorkHours(Integer workHours) {
        this.workHours = this.workHours + workHours;
    }

    public void incrementOvertimeWorkHours(Integer overtimeWorkHours) {
        this.overtimeWorkHours = this.overtimeWorkHours  + overtimeWorkHours;
    }

    public void setLastFinishTime(Date lastFinishTime) {
        this.lastFinishTime = lastFinishTime;
    }

    public void setHoursPerToday(Integer hoursPerToday) {
        this.hoursPerToday = hoursPerToday;
    }

    public void incrementTaskCount(Task taskType) {
        this.taskCount[taskType.getId() - 1] = this.taskCount[taskType.getId() - 1] + 1;
    }

    public Integer getHoursPerToday() {
        return hoursPerToday;
    }

}
