package org.factory.project.model;

public class Operation {
}
