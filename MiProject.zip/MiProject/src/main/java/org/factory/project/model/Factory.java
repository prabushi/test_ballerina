package org.factory.project.model;

public class Factory {
}
