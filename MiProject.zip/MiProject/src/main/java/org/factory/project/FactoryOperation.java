package org.factory.project;

import org.factory.project.model.Job;
import org.factory.project.model.Task;
import org.factory.project.model.input.DfAllocation;
import org.factory.project.model.input.OperationData;
import org.factory.project.model.input.WorkerInput;
import org.factory.project.utils.FactoryUtils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class FactoryOperation {
    public static final Integer JOB_COUNT = 12;
    private static final Integer OVERTIME_HOURS = 2;

    public static void main(String[] args) throws ParseException {
        Job[] jobList = getJobList();

        // job id, <operation_id, operation>
        Map<Integer, Map<Integer, OperationData>> operationMap = new HashMap<>();
        for (int i = 0; i < JOB_COUNT; i++) {
            operationMap.put(i + 1, new HashMap<>());
        }

        Map<Integer, Date> jobDueDates = new HashMap<>();
        List<Integer> jobPriorityList = new ArrayList<>();

        List<DfAllocation> allocations = FactoryUtils.readDfAllocationInput("/Users/ts-p.samarakoonarach/Rakuten/practice/MiProject/src/main/resources/input/df_Allocation_pyCharm_iterated_1.csv");
        for (DfAllocation allocation : allocations) {
            System.out.println(allocation.toString());
        }

        List<WorkerInput> workerInputs = FactoryUtils.readEngineerInput();
        for (WorkerInput workerInput : workerInputs) {
            System.out.println(workerInput.toString());
        }

        List<OperationData> operationDataList = FactoryUtils.readJobData();
        for (OperationData operationData : operationDataList) {
            int jobId = operationData.getJobId();
            int operationId = operationData.getOperationId();
            Date dueDate = operationData.getDueDate();
            operationMap.get(jobId).put(operationId, operationData);

            if (!jobDueDates.containsKey(jobId)) {
                jobDueDates.put(jobId, dueDate);
            }

            jobList[jobId - 1].getOperationDataList().add(operationData);

            System.out.println(operationData);
        }

        //Create job priority list
        // TODO: we can change the order when it has the same date
        List<Date> sortedDateList = jobDueDates.values().stream().sorted().collect(Collectors.toList());
        for (Date time : sortedDateList) {
            jobDueDates.entrySet().forEach(entry -> {
                if (entry.getValue() == time) {
                    jobPriorityList.add(entry.getKey());
                }
            });
        }

        //TODO: create worker priority list

        // Set dependencies
        for (OperationData operationData : operationDataList) {
            List<Integer> precedences = operationData.getPrecedingOperations();
            int jobId = operationData.getJobId();
            for (Integer p : precedences) {
                operationData.addDependency(operationMap.get(jobId).get(p.intValue()));
            }
        }

//        factoryRun(jobPriorityList, jobList, workerInputs);

//        int finishedJobs = 0;
//        while (finishedJobs < JOB_COUNT) {
        calculateTimeConsumption(allocations, workerInputs, jobList);
//            finishedJobs = getFinhishedJobCount();
//        }

        writeOutput(allocations);
    }

    public static Job[] getJobList() {
        return new Job[]{new Job(1), new Job(2), new Job(3), new Job(4), new Job(5),
                new Job(6), new Job(7), new Job(8), new Job(9), new Job(10), new Job(11), new Job(12)};
    }

    private static void writeOutput(List<DfAllocation> allocations) {
        System.out.println("=== output ===");
        String result = ",Job,Operation,Task type,Standard time,Allocated Worker,Processing_time,Start_time,End_time\n";
        for (DfAllocation allocation : allocations) {
            result = result.concat(allocation.toString()).concat("\n");

        }
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("result_4.csv"));
            writer.write(result);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        System.out.println("=== output2 ===");
        System.out.println(result);
    }

    public static void calculateTimeConsumption(List<DfAllocation> allocations, List<WorkerInput> workerInputs, Job[] jobList) {

        for (DfAllocation allocation : allocations) {

            WorkerInput worker = workerInputs.get(allocation.getWorkerId() - 1);

            int processingTime = allocation.getProcessingTime();


            Date possibleStartTime = worker.getLastFinishTime();
            if (!hasAllDependenciesSetTime(jobList, allocation.getJobId(), allocation.getOperationId())) {
                System.out.println("=== skip operation == " + allocation.getJobId() + ":" + allocation.getOperationId());
                continue;
            } else {
                Date newDate = getPossibleStartTime(jobList, allocation.getJobId(), allocation.getOperationId(), possibleStartTime);
                if (!newDate.equals(possibleStartTime)) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(newDate);
                    int hours = calendar.get(Calendar.HOUR_OF_DAY);
                    int todayLeftTime = worker.getWorkingTime() + OVERTIME_HOURS - (hours - 9);
                    if (todayLeftTime > 0) {
                        worker.setHoursPerToday(hours - 9);
                        possibleStartTime = newDate;

                    } else {
                        worker.setHoursPerToday(0);
                        possibleStartTime = getNextDayStart(newDate);
                    }
                }
            }

            int todayHours = worker.getHoursPerToday();
            worker.setLastFinishTime(possibleStartTime); // Might not need
            allocation.setStartTime(possibleStartTime);

            int workingHours = worker.getWorkingTime(); // +2 overtime

            if ((todayHours + processingTime) < (workingHours + OVERTIME_HOURS)) {
                // within the day
                if ((todayHours + processingTime) <= workingHours) {
                    worker.incrementWorkHours(processingTime);
                    worker.incrementOvertimeWorkHours(0);

                } else {
                    // use overtime
                    int ot = todayHours + processingTime - workingHours;
                    int nonOt = processingTime - ot;

                    worker.incrementWorkHours(nonOt);
                    worker.incrementOvertimeWorkHours(ot);
                }

                allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(processingTime, ChronoUnit.HOURS)));
                worker.setLastFinishTime(allocation.getEndTime());
                worker.setHoursPerToday(todayHours + processingTime);

            } else if ((todayHours + processingTime) == (workingHours + OVERTIME_HOURS)) {
                // set today's hours 0 and next day's 9 as finish time
                // can be just OT or OT + nonOT

                if (todayHours > workingHours) {
                    //OT
                    worker.incrementWorkHours(0);
                    worker.incrementOvertimeWorkHours(processingTime);
                } else {
                    int ot = todayHours + processingTime - workingHours;
                    int nonOt = processingTime - ot;

                    worker.incrementWorkHours(nonOt);
                    worker.incrementOvertimeWorkHours(ot);
                }

                allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(processingTime, ChronoUnit.HOURS)));
                worker.setLastFinishTime(getNextDayStart(allocation.getEndTime()));
                worker.setHoursPerToday(0);

            } else {
                // (todayHours + processingTime) > (workingHours + OVERTIME_HOURS) -> break to next day
                int doneProcessingTime = 0;
                Date initialOperationStartTime = allocation.getStartTime();

                while (processingTime > 0) {

                    todayHours = worker.getHoursPerToday();
                    if (todayHours + processingTime <= workingHours) {
                        // finish today in the middle
                        worker.incrementWorkHours(processingTime);
                        worker.incrementOvertimeWorkHours(0);
                        doneProcessingTime = processingTime;
                        allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(processingTime, ChronoUnit.HOURS)));
                        worker.setHoursPerToday(todayHours + processingTime);
                        worker.setLastFinishTime(allocation.getEndTime());

                    } else if (todayHours + processingTime < workingHours + OVERTIME_HOURS) {
                        // finish today in the middle of OT
                        int ot = todayHours + processingTime - workingHours;
                        worker.incrementWorkHours(0);
                        worker.incrementOvertimeWorkHours(ot);
                        doneProcessingTime = ot;
                        allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(ot, ChronoUnit.HOURS)));
                        worker.setHoursPerToday(todayHours + ot);
                        worker.setLastFinishTime(allocation.getEndTime());

                    } else if (todayHours + processingTime == workingHours + OVERTIME_HOURS) {
                        // finish today exact at the end
                        int ot = todayHours + processingTime - workingHours;
                        worker.incrementWorkHours(0);
                        worker.incrementOvertimeWorkHours(ot);
                        doneProcessingTime = ot;

                        allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(ot, ChronoUnit.HOURS)));
                        worker.setLastFinishTime(getNextDayStart(allocation.getEndTime()));
                        worker.setHoursPerToday(0);

                    } else {
                        // if split the day
                        int totalCanToday = workingHours + OVERTIME_HOURS - todayHours;
                        if (totalCanToday <= OVERTIME_HOURS) {
                            // only OT
                            worker.incrementWorkHours(0);
                            worker.incrementOvertimeWorkHours(totalCanToday);

                        } else {
                            // OT + nonOT
                            worker.incrementWorkHours(totalCanToday - OVERTIME_HOURS);
                            worker.incrementOvertimeWorkHours(OVERTIME_HOURS);
                        }
                        doneProcessingTime = totalCanToday;
                        // go to next day

                        allocation.setEndTime(Date.from(allocation.getStartTime().toInstant().plus(doneProcessingTime, ChronoUnit.HOURS)));
                        worker.setHoursPerToday(0);
                        worker.setLastFinishTime(getNextDayStart(allocation.getEndTime()));
                    }

                    allocation.setStartTime(worker.getLastFinishTime());
                    processingTime = processingTime - doneProcessingTime;
                }

                allocation.setStartTime(initialOperationStartTime);

            }

            worker.incrementTaskCount(allocation.getTaskType());
            markOperationFinishTime(jobList, allocation.getJobId(), allocation.getOperationId(), allocation.getEndTime());
        }

    }

    private static void factoryRun(List<Integer> jobPriorityList, Job[] jobList, List<WorkerInput> workerInputs) {
        int completedJobs = 0;
        //TODO consider OT
        int currentDays = 0;
        int currentHours = 0; // 9 am to 5 am
        int currentMinutes = 0;

        while (completedJobs < JOB_COUNT) {

            for (int i = 0; i < jobPriorityList.size(); i++) {
                int jobId = jobPriorityList.get(i);

                Job job = jobList[jobId - 1];
                if (job.isFinishedSettingTime()) {
                    continue;
                }

                int currentOperationId = job.getCurrentProcessingOperationId();
                List<OperationData> operationDataList = job.getOperationDataList();
                OperationData currentOperation = operationDataList.get(currentOperationId);

//                if (currentOperation.getOperationComplete()) {
//                    // TODO: Is this possible? if so get next?
//                    System.out.println("1: op completed " + jobId + ":" + currentOperationId);
//                } else {
//                    Integer workerId = getWorker(workerInputs, currentOperation.getTaskType(), currentOperation.getRequiredSkillLimit());
//                    if (workerId == -1) {
//                        //TODO: not possible
//                        System.out.println("2: no worker can be allocated " + jobId + ":" + currentOperationId);
//                        continue;
//                    }
//
//
//                }


            }

        }
    }

    private static Integer getWorker(List<WorkerInput> workerInputs, Task taskType, Double skillLimit) {
        for (int i = 0; i < workerInputs.size(); i++) {
            WorkerInput worker = workerInputs.get(i);

//            if (worker.isWorking()) {
//                continue;
//            }

            if (worker.getSkillLimit(taskType) >= skillLimit) {
                return worker.getWorkerId();
            }
        }
        return -1;
    }

    private static Date getNextDayStart(Date date) {
        // Return next day 9 am
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minutes = calendar.get(Calendar.MINUTE);
        int seconds = calendar.get(Calendar.SECOND);

        return Date.from(date.toInstant().plus(60 - minutes - 1, ChronoUnit.MINUTES)
                .plus(60 - seconds, ChronoUnit.SECONDS)
                .plus(24 - hours - 1 + 9, ChronoUnit.HOURS));
    }

    private static boolean hasAllDependenciesSetTime(Job[] jobList, int jobId, int operationId) {
        List<OperationData> operationData = jobList[jobId - 1].getOperationDataList();
        List<OperationData> dependencies = operationData.get(operationId - 1).getDependentOperations();
        if (dependencies == null || dependencies.size() == 0) {
            return true;
        }

        for (int i = 0; i < dependencies.size(); i++) {
            OperationData op = dependencies.get(i);
            if (!op.isHasSetTime()) {
                return false;
            }
        }

        return true;
    }

    private static Date getPossibleStartTime(Job[] jobList, int jobId, int operationId, Date possibleStartTime) {
        List<OperationData> operationData = jobList[jobId - 1].getOperationDataList();
        List<OperationData> dependencies = operationData.get(operationId - 1).getDependentOperations();
        if (dependencies == null || dependencies.size() == 0) {
            return possibleStartTime;
        }

        Date lastestDate = possibleStartTime;

        for (int i = 0; i < dependencies.size(); i++) {
            OperationData op = dependencies.get(i);
            if (op.getFinishTime().after(lastestDate)) {
                lastestDate = op.getFinishTime();
            }
        }

        return lastestDate;
    }

    private static int getFinhishedJobCount(Job[] jobList, Date date) {
        for (int i = 0; i < jobList.length; i++) {
            if (jobList[i].isFinishedSettingTime()) {
                continue;
            }
            List<OperationData> operationData = jobList[i].getOperationDataList();
            for (int j = 0; j < operationData.size(); j++) {
                OperationData op = operationData.get(j);
//                if ()
            }
        }
        return 0;
    }

    private static void markOperationFinishTime(Job[] jobList, int jobId, int operationId, Date date) {
        List<OperationData> operationData = jobList[jobId - 1].getOperationDataList();
        operationData.get(operationId - 1).setFinishTime(date);
        operationData.get(operationId - 1).setHasSetTime(true);
    }
}
