package org.factory.project.model.input;

import org.factory.project.model.Task;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DfAllocation {
    //2023-12-01 19:00:00
    private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Integer id;
    Integer jobId;
    Integer operationId;
    Task taskType;
    Integer standardTime;
    Integer workerId;
    Integer processingTime;
    Date startTime;
    Date endTime;
    public DfAllocation(Integer id, Integer jobId, Integer operationId, Task taskType, Integer standardTime, Integer workerId, Integer processingTime, String startTime, String endTime) throws ParseException {
        this.id = id;
        this.jobId = jobId;
        this.operationId = operationId;
        this.taskType = taskType;
        this.standardTime = standardTime;
        this.workerId = workerId;
        this.processingTime = processingTime;
        this.startTime = formatter.parse(startTime);
        this.endTime = formatter.parse(endTime);
    }

    @Override
    public String toString() {
        return
                id +
                "," + jobId +
                "," + operationId +
                "," + taskType.getId() +
                "," + standardTime +
                "," + workerId +
                "," + processingTime +
                "," + formatter.format(startTime) +
                "," + formatter.format(endTime);
    }

    public Integer getId() {
        return id;
    }

    public Integer getJobId() {
        return jobId;
    }

    public Integer getOperationId() {
        return operationId;
    }

    public Task getTaskType() {
        return taskType;
    }

    public Integer getStandardTime() {
        return standardTime;
    }

    public Integer getWorkerId() {
        return workerId;
    }

    public Integer getProcessingTime() {
        return processingTime;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public void setOperationId(Integer operationId) {
        this.operationId = operationId;
    }

    public void setTaskType(Task taskType) {
        this.taskType = taskType;
    }

    public void setStandardTime(Integer standardTime) {
        this.standardTime = standardTime;
    }

    public void setWorkerId(Integer workerId) {
        this.workerId = workerId;
    }

    public void setProcessingTime(Integer processingTime) {
        this.processingTime = processingTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
