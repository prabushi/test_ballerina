package org.factory.project.model;

import org.factory.project.model.input.OperationData;

import java.util.ArrayList;
import java.util.List;

public class Job {
    int jobId;
    List<OperationData> operationDataList = new ArrayList<>();
    int currentProcessingOperationId = 1;

    boolean isFinishedSettingTime = false;

    public Job(int jobId) {
        this.jobId = jobId;
    }

    public List<OperationData> getOperationDataList() {
        return operationDataList;
    }

    public int getJobId() {
        return jobId;
    }

    public int getCurrentProcessingOperationId() {
        return currentProcessingOperationId;
    }

    public boolean isFinishedSettingTime() {
        return isFinishedSettingTime;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public void setOperationDataList(List<OperationData> operationDataList) {
        this.operationDataList = operationDataList;
    }

    public void setCurrentProcessingOperationId(int currentProcessingOperationId) {
        this.currentProcessingOperationId = currentProcessingOperationId;
    }

    public void setFinishedSettingTime(boolean finishedSettingTime) {
        isFinishedSettingTime = finishedSettingTime;
    }
}
