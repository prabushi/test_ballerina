package org.factory.project.utils;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.factory.project.model.Task;
import org.factory.project.model.TaskItem;
import org.factory.project.model.WorkerTaskItem;
import org.factory.project.model.input.DfAllocation;
import org.factory.project.model.input.WorkerInput;
import org.factory.project.model.input.OperationData;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class FactoryUtils {
    public static List<DfAllocation> readDfAllocationInput(String fileName) throws ParseException {
        String csvFile = fileName;
        List<DfAllocation> dfAllocations = new ArrayList<>();

        boolean isFirst = true;
        try (Reader reader = new FileReader(csvFile);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT)) {

            for (CSVRecord csvRecord : csvParser) {
                if (isFirst) {
                    isFirst = false;
                    continue;
                }
                int id = Integer.parseInt(csvRecord.get(0));
                int job = Integer.parseInt(csvRecord.get(1));
                int operation = Integer.parseInt(csvRecord.get(2));
                Task taskType = Task.getTaskFromId(Integer.parseInt(csvRecord.get(3)));
                int standardType = Integer.parseInt(csvRecord.get(4));
                int worker = Integer.parseInt(csvRecord.get(5));
                int processingTime = Integer.parseInt(csvRecord.get(6));
                String startTime = csvRecord.get(7);
                String endTime = csvRecord.get(8);

                DfAllocation allocation = new DfAllocation(id, job, operation, taskType, standardType, worker, processingTime, startTime, endTime);
                dfAllocations.add(allocation);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return dfAllocations;
    }

    public static List<WorkerInput> readEngineerInput() throws ParseException {
        String csvFile = "/Users/ts-p.samarakoonarach/Rakuten/practice/MiProject/src/main/resources/input/engineer_input_data.csv";
        List<WorkerInput> workerInputs = new ArrayList<>();

        int count = 0;
        try (Reader reader = new FileReader(csvFile);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT)) {

            for (CSVRecord csvRecord : csvParser) {
                if (count < 2) {
                    count++;
                    continue;
                }

                int worker = Integer.parseInt(csvRecord.get(0));
                int rank = Integer.parseInt(csvRecord.get(1));
                int workingTime = Integer.parseInt(csvRecord.get(2));

                WorkerTaskItem taskItem1 = new WorkerTaskItem(new TaskItem(Double.parseDouble(csvRecord.get(3)), Task.TASK_1));
                WorkerTaskItem taskItem2 = new WorkerTaskItem(new TaskItem(Double.parseDouble(csvRecord.get(4)), Task.TASK_2));
                WorkerTaskItem taskItem3 = new WorkerTaskItem(new TaskItem(Double.parseDouble(csvRecord.get(5)), Task.TASK_3));
                WorkerTaskItem taskItem4 = new WorkerTaskItem(new TaskItem(Double.parseDouble(csvRecord.get(6)), Task.TASK_4));
                WorkerTaskItem[] taskItemList = new WorkerTaskItem[]{taskItem1, taskItem2, taskItem3, taskItem4};

                String assignedJobs = csvRecord.get(7);
                String[] taskCounts = csvRecord.get(8).split(",");
                Integer[] taskCount = new Integer[]{Integer.parseInt(taskCounts[0]), Integer.parseInt(taskCounts[1]), Integer.parseInt(taskCounts[2]), Integer.parseInt(taskCounts[3])};
                int workHours = Integer.parseInt(csvRecord.get(9).isBlank() ? "-1" : csvRecord.get(9));
                int overtimeWorkHours = Integer.parseInt(csvRecord.get(10).isBlank() ? "-1" : csvRecord.get(10));
                String lastFinishTime = csvRecord.get(11);

                WorkerInput workerInput = new WorkerInput(worker, rank, workingTime, taskItemList, assignedJobs, taskCount, workHours, overtimeWorkHours, lastFinishTime);
                workerInputs.add(workerInput);
                count++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return workerInputs;
    }

    public static List<OperationData> readJobData() throws ParseException {
        String csvFile = "/Users/ts-p.samarakoonarach/Rakuten/practice/MiProject/src/main/resources/input/new_job_data.csv";
        List<OperationData> operationDataList = new ArrayList<>();

        int count = 0;
        try (Reader reader = new FileReader(csvFile);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT)) {

            for (CSVRecord csvRecord : csvParser) {
                if (count < 2) {
                    count++;
                    continue;
                }

                int jobId = Integer.parseInt(csvRecord.get(0));
                int operationId = Integer.parseInt(csvRecord.get(1));
                if (operationId == 0) {
                    count++;
                    continue;
                }
                int standardTime = Integer.parseInt(csvRecord.get(2));
                Task taskType = Task.getTaskFromId(Integer.parseInt(csvRecord.get(3)));
                Double requiredSkillLimit = Double.parseDouble(csvRecord.get(4));
                String[] preOps = csvRecord.get(5).split(",");
                List<Integer> precedingOperations = new ArrayList<>();
                for (int i = 0; i < preOps.length; i++) {
                    String op = preOps[i];
                    precedingOperations.add(Integer.parseInt(op));
                }

                boolean operationComplete = Integer.parseInt(csvRecord.get(6)) == 1;
                String lastCompletion = csvRecord.get(7);
                String dueDate = csvRecord.get(8);
                String finishTime = csvRecord.get(9);
                //TODO: change
                List<Integer> assignedWorkers = csvRecord.get(10).isBlank() ? new ArrayList<>() : List.of(Integer.parseInt(csvRecord.get(10)));

                OperationData operationData = new OperationData(jobId, operationId, standardTime, taskType,requiredSkillLimit, precedingOperations, operationComplete,lastCompletion,dueDate,finishTime, assignedWorkers);
                operationDataList.add(operationData);
                count++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return operationDataList;
    }
}
