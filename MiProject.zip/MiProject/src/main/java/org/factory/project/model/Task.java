package org.factory.project.model;

public enum Task {
    // This is n operation category.
    TASK_1(1, "Part drawing"),
    TASK_2(2, "Sub assembly, assembly, drawing"),
    TASK_3(3, "Final assembly"),
    TASK_4(4, "EBOM (How many parts in a sub part)");
    private final String name;
    private final int id;

    Task(int id, String name) {
        this.name = name;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static Task getTaskFromId(int id) {
        if (id == 1) return TASK_1;
        if (id == 2) return TASK_2;
        if (id == 3) return TASK_3;
        if (id == 4) return TASK_4;
        return null;
    }
}
