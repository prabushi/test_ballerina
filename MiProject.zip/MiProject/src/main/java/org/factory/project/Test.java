package org.factory.project;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

public class Test {
    public static void main(String[] args) {
        Date _now = new Date();
        System.out.println(_now);
        Instant _instant = _now.toInstant().minus(5, ChronoUnit.DAYS);
        Date _newDate = Date.from(_instant);
        System.out.println(_newDate);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(_newDate);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minutes = calendar.get(Calendar.MINUTE);
        int seconds = calendar.get(Calendar.SECOND);

       Date t = Date.from(_newDate.toInstant().plus(60 - minutes - 1, ChronoUnit.MINUTES)
                .plus(60 - seconds, ChronoUnit.SECONDS)
                .plus(24 - hours - 1 + 9, ChronoUnit.HOURS));


        System.out.println(hours + " " + minutes + " " + seconds + " t" + t);
    }
}
